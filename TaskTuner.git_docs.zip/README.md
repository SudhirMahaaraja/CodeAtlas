# TaskTuner.git

## Description

A project statically analyzed by CodeAtlas.


## 🛠️ Tech Stack & Frameworks

**Detected Frameworks/Technologies:**

- Flask



### Dependencies


- `Flask` (2.0.0) - via *requirements.txt*

- `python-dotenv` (1.0.0) - via *requirements.txt*

- `requests` (2.0.0) - via *requirements.txt*

- `pytest` (7.0.0) - via *requirements.txt*




## 📁 File Structure
```text

app.py (python, 30 LOC)

config.py (python, 9 LOC)

controllers/page_controller.py (python, 56 LOC)

controllers/schedule_controller.py (python, 11 LOC)

controllers/task_controller.py (python, 28 LOC)

controllers/__init__.py (python, 0 LOC)

models/schedule.py (python, 13 LOC)

models/task.py (python, 39 LOC)

models/__init__.py (python, 0 LOC)

services/asana_service.py (python, 0 LOC)

services/scheduling.py (python, 38 LOC)

services/trello_service.py (python, 46 LOC)

services/__init__.py (python, 0 LOC)

tests/test_schedule.py (python, 0 LOC)

tests/test_tasks.py (python, 0 LOC)

tests/__init__.py (python, 0 LOC)

views/templates/base.html (html, 57 LOC)

views/templates/home.html (html, 161 LOC)

views/templates/schedule.html (html, 90 LOC)

views/templates/tasks.html (html, 125 LOC)

```

## 🚀 Setup & Execution

### Python/Backend Project Setup
1. **Create Virtual Environment:**
   ```bash
   python -m venv .venv
   source .venv/bin/activate  # On Windows: .venv\Scripts\activate
   ```
2. **Install Dependencies:**
   ```bash
   pip install -r requirements.txt
   ```
3. **Run Application:**
   
   ```bash
   flask run
   ```
   




---
*README generated automatically by [CodeAtlas](https://github.com/your-repo/codeatlas) with zero LLM calls.*